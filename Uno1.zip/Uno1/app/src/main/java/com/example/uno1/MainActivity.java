package com.example.uno1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recycler;
    ArrayList<Carta> baraja, listaCartas;
    private Button Centro;
    private ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = (RecyclerView) findViewById(R.id.recycler);
        recycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false));

        Centro = (Button)findViewById(R.id.Centro);
        imagen = (ImageView)findViewById(R.id.imgImagen);

    }

    public void empezar(View view) {
        //cargar la baraja
        crearBaraja();

        //cargar el maso del jugador, se eligen 7 cartas
        listaCartas = new ArrayList<>();
        for(int k =0; k<7; k++){
            int i = (int)(Math.random() * 108);
            modificarMaso(0,i);
        }

        //cargar la carta del centro
        int i = (int) ((Math.random() * 99));
        cargarCartaCentral(i);
        recycler.setVisibility(View.VISIBLE);
    }

    public void crearBaraja(){
        baraja = new ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            //aqui la i actua como un color
            baraja.add(new Carta(0, 1, getResources().getIdentifier("c"+i+"0","drawable",getPackageName())));
        }
        //cartas normales, cartas regreso, cartas salto, carta +2
        int color = 1;
        while (color < 5) {
            for (int i = 1; i < 13; i++) {
                baraja.add(new Carta(i, color, getResources().getIdentifier("c"+color+""+i,"drawable",getPackageName())));
                baraja.add(new Carta(i, color, getResources().getIdentifier("c"+color+""+i,"drawable",getPackageName())));
            }
            color++;
        }
        //comodines
        for (int i = 0; i < 4; i++) {
            baraja.add(new Carta(13, 5, getResources().getIdentifier("c513","drawable",getPackageName())));
        }
        //+4
        for (int i = 0; i < 4; i++) {
            baraja.add(new Carta(14, 5,getResources().getIdentifier("c514","drawable",getPackageName())));
        }
        for(int i = 0; i < baraja.size(); i++){
            baraja.get(i).setId(i);
        }
    }

    public void modificarMaso(int operacion, int id){
        if(operacion == 0){
            listaCartas.add(baraja.get(id));
        }else if(operacion == 1){
            listaCartas.remove(baraja.get(id));
        }

        AdapterDatos adapterDatos = new AdapterDatos(listaCartas);
        adapterDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "Seleccion: "+listaCartas.get(recycler.getChildAdapterPosition(v)).getNumero(), Toast.LENGTH_SHORT).show();
                poner(v);
            }
        });
        recycler.setAdapter(adapterDatos);
    }

    public void cargarCartaCentral(int id){
        //nombre
        Centro.setText(id+". Carta: "+baraja.get(id).getNumero());
        //Color y carta
        imagen.setImageResource(getResources().getIdentifier("c"+baraja.get(id).getColor()+""+baraja.get(id).getNumero(), "drawable",getPackageName()));
    }

    public void comer(View view){
        int v = recycler.getVisibility();
        if( v == View.INVISIBLE){
            Toast.makeText(this, "No ha empezado el juego",Toast.LENGTH_LONG).show();
        }else {
            //comer añade una carta al juego
            int i = (int) ((Math.random() * 107));
            modificarMaso(0, i);
        }
    }

    public String obtenerId(String cadena){
        String save = "";
        for (int i = 0; i < cadena.length(); i++) {
            String t = cadena.charAt(i) + "";
            if (t.equals(".")) {
                break;
            } else {
                save += t;
            }
        }
        return save;
    }

    public void poner(View v){
        //obten la informacion de la carta en el maso del jugador
        final int idMaso = listaCartas.get(recycler.getChildAdapterPosition(v)).getId();
        int colorMaso = baraja.get(idMaso).getColor();
        int numMaso = baraja.get(idMaso).getNumero();

        //obtener la informacion del centro
        final int idCentro = Integer.parseInt(obtenerId(Centro.getText().toString()));
        final int colorCentro = baraja.get(idCentro).getColor();
        final int numCentro = baraja.get(idCentro).getNumero();

        //comparar centro con la carta del maso
        //verificar si es b13
        if(colorMaso == colorCentro || numMaso == numCentro || numMaso == 13 || numMaso == 14){

            //aceptado. Poner carta del centro
            if(numMaso == 13 || numMaso == 14){
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.dialog_colores, null);
                Button btnRojo = mView.findViewById(R.id.btnRojo);
                Button btnVerde = mView.findViewById(R.id.btnVerde);
                Button btnAzul = mView.findViewById(R.id.btnAzul);
                Button btnAmarillo = mView.findViewById(R.id.btnAmarillo);

                btnRojo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        baraja.get(idMaso).setColor(1);
                        Centro.setBackgroundColor(Color.RED);
                    }
                });
                btnVerde.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        baraja.get(idMaso).setColor(2);
                        Centro.setBackgroundColor(Color.GREEN);
                    }
                });
                btnAzul.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        baraja.get(idMaso).setColor(3);
                        Centro.setBackgroundColor(Color.BLUE);
                    }
                });
                btnAmarillo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        baraja.get(idMaso).setColor(4);
                        Centro.setBackgroundColor(Color.YELLOW);
                    }
                });
                alert.setOnCancelListener(new DialogInterface.OnCancelListener(){

                    @Override
                    public void onCancel(DialogInterface dialog) {
                        if(baraja.get(idMaso).getColor() == 5){
                            modificarMaso(0, idMaso);
                            cargarCartaCentral(idCentro);
                        }
                    }
                });
                alert.setView(mView);
                AlertDialog dialog = alert.create();
                dialog.show();
            }

            cargarCartaCentral(idMaso);
            modificarMaso(1, idMaso);
        }else{
            Toast.makeText(this, "Esta carta no se puede poner", Toast.LENGTH_SHORT).show();
        }

    }
}
