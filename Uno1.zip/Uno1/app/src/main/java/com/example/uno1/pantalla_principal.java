package com.example.uno1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class pantalla_principal extends AppCompatActivity {

    private Button btnJugador;
    private Button btnMultijugador;
    private EditText nombre;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_principal);

        btnJugador = (Button)findViewById(R.id.btnUnJugador);
        btnMultijugador = (Button)findViewById(R.id.btnMultijugador);
        nombre = (EditText) findViewById(R.id.nombre);

    }

    public void unJugador(View view){
        Intent main = new Intent(this, MainActivity.class);
        startActivity(main);
    }

    public void Multijugador(View view){
        Intent main = new Intent(this, multijugador.class);
        main.putExtra("nombre", nombre.getText().toString());
        startActivity(main);
    }
}
