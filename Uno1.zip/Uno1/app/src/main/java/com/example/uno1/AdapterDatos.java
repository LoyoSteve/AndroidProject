package com.example.uno1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos>
implements View.OnClickListener {

    ArrayList<Carta> listaCartas;
    View.OnClickListener listener;

    public AdapterDatos(ArrayList<Carta> listDatos) {
        this.listaCartas = listDatos;
    }
    public void setOnClickListener(View.OnClickListener listener){
        this.listener = listener;
    }

    @Override
    public AdapterDatos.ViewHolderDatos onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item,null,false);
        view.setOnClickListener(this);
        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(AdapterDatos.ViewHolderDatos holder, int position) {
        holder.imagen.setImageResource(listaCartas.get(position).getImagen());
    }

    @Override
    public int getItemCount() {
        return listaCartas.size();
    }

    @Override
    public void onClick(View v) {
        if(listener != null){
            listener.onClick(v);
        }
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {

        ImageView imagen;

        public ViewHolderDatos(View itemView) {
            super(itemView);
            imagen = itemView.findViewById(R.id.imagenCarta);
        }

    }
}
