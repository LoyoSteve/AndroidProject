package com.example.uno1;

public class Carta {
    private int numero; //10 regreso; 11 salto; 12 +2; 13 comodines; 14 +4
    private int color; //1 red; 2 green; 3 blue; 4 yellow; 5 ninguno
    private int imagen; //nombre de la imagen
    private int id;

    public Carta(int num, int col, int foto){
        numero = num;
        color = col;
        imagen = foto;
        id = 0;
    }

    public int getNumero(){
        return numero;
    }

    public int getColor(){
        return color;
    }

    public int getImagen(){
        return imagen;
    }

    public int getId(){return id;}

    public void setColor(int color){
        this.color = color;
    }

    public void setId(int i){
        this.id = i;
    }
}
