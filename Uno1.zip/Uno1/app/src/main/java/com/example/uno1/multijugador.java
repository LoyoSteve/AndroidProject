package com.example.uno1;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class multijugador extends AppCompatActivity {

    private EditText ip;
    private String nombre = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.multijugador);

        ip = (EditText) findViewById(R.id.ip);
        /*Bundle datos = this.getIntent().getExtras();
        nombre = datos.getString("nombre");
        ip.setText(nombre);*/
    }

    protected void conectar(View View) {
        
    }
}
